import java.util.ArrayList;

class Almacen {
    ArrayList<Fruta> frutas;
    
    Almacen() {
        frutas = new ArrayList<Fruta>();
    }
    
    void agregarFruta(Fruta fruta) {
        frutas.add(fruta);
    }
    
    Fruta frutaMasPesada() {
        Fruta masPesado = new Fruta(0,0,0);
        for(int i = 0; i < frutas.size(); i++) {
            if(!masPesado.mayorPeso(frutas.get(i))) {
                masPesado = frutas.get(i);
            }
        }
        return masPesado;
    }
    
    Fruta menorPrecio() {
        Fruta res = new Fruta(0,0,0);
        for(int i = 0; i < frutas.size(); i++) {
            if(res.mayorPrecio(frutas.get(i))) {
                res = frutas.get(i);
            }
        }
        return res;
    }
}