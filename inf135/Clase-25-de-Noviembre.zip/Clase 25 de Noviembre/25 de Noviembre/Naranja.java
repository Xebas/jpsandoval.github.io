class Naranja extends Fruta {
    int cantidadJugo;
    
    Naranja(int cantidadJ, int peso, int volumen, int pre) {
        super(peso, volumen, pre);
        cantidadJugo = cantidadJ;
    }
    
    boolean cantidadJugo(Naranja otro) {
        return cantidadJugo > otro.cantidadJugo;
    }
}