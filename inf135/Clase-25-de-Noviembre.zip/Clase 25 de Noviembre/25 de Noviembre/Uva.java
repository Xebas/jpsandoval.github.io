class Uva extends Fruta {
    Uva(int p, int v, int pre) {
        super(p, v, pre);
    }
}