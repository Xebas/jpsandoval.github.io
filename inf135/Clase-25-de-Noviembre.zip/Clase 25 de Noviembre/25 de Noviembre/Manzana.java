class Manzana extends Fruta {
    Manzana(int p, int v, int pre) {
        super(p, v, pre);
    }
}