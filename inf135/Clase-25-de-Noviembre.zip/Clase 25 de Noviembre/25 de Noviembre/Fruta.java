class Fruta {
    int peso;
    int volumen;
    int precio;
    
    Fruta(int p, int v, int pre) {
        peso = p;
        volumen = v;
        precio = pre;
    }
    
    boolean mayorPeso(Fruta otro) {
        return peso > otro.peso;
    }

    String compararVolumen(Fruta otro) {
        String res ="";
        if(volumen > otro.volumen) {
            res = "tiene mayor volumen";
        } else if(volumen == otro.volumen) {
            res = "tienen igual volumen";
        } else {
            res = "tiene menor volumen";
        }
        return res;
    }
    
    boolean mayorPrecio(Fruta otra) {
        return precio > otra.precio;
    }
}