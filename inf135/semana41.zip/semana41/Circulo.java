class Circulo{
    Punto centro;
    double radio;
    //constructor
    Circulo(Punto c,double r){
        centro=c;
        radio=r;
    }
    //metodos
    double area(){
        return Math.PI*Math.pow(radio,2);
    }
    double perimetro(){
        return 2*Math.PI*radio;
    }
    
    boolean intersecta(Circulo otro){
        //...
        return false;
    }
    
    boolean contiene(Punto point){
        //...
        return false;
    }
    
}






