class Punto{
    int x;
    int y;
    Punto(int xo,int yo){
        x=xo;
        y=yo;
    }
}