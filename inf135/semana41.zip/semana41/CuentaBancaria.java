class CuentaBancaria{
    int saldo;
    CuentaBancaria(int saldoInicial){
        saldo = saldoInicial;
    }
    void depositar(int monto){
        saldo = saldo + monto;
    }
    void retirar(int monto){
        if(monto<=saldo){
            saldo = saldo - monto;
        }
    }
}