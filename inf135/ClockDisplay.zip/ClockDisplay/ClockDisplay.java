class ClockDisplay{
    NumberDisplay hora;
    NumberDisplay min;
    
    ClockDisplay(int h,int m){
        hora= new NumberDisplay(h,24);
        min= new NumberDisplay(m,60);
    }
    void increment(){
        if(min.increment()){
            hora.increment();
        }
    }
    
    String asString(){
        return hora.asString()+":"+ min.asString();
    }
}