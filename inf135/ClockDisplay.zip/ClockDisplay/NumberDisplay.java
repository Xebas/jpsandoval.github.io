
public class NumberDisplay{
    int value;
    int limit;
    
    NumberDisplay(int v,int l){
        value = v;
        limit = l;
    }
    boolean increment(){
        boolean overflow=false;
        value = value + 1;
        if(value>=limit){
            value = 0; overflow=true;
        }
        return overflow;
    }
    
    
    String asString(){
        String res="";
        if(value<10){
            res = "0";
        }
        res = res+value;
        return res;
    }
}
