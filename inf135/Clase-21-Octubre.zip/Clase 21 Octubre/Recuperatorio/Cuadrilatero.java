/**
 *          lado1
 *      p1-----------p2
 *      |            |
 * lado4|            |lado2
 *      |            |
 *      p4-----------p3
 *          lado3
 */
class Cuadrilatero {
    Point punto1;
    Point punto2;
    Point punto3;
    Point punto4;
    
    Cuadrilatero(Point punto1, Point punto2, Point punto3, Point punto4) {
        this.punto1 = punto1;
        this.punto2 = punto2;
        this.punto3 = punto3;
        this.punto4 = punto4;
    }
    
    double perimetro() {
        double lado1, lado2, lado3, lado4;
        lado1 = punto1.distance(punto2);
        lado2 = punto2.distance(punto3);
        lado3 = punto3.distance(punto4);
        lado4 = punto4.distance(punto1);
        return lado1 + lado2 + lado3 + lado4;
    }
    
    boolean esCuadrado() {
        boolean res;
        double lado1, lado2, lado3, lado4;
        lado1 = punto1.distance(punto2);
        lado2 = punto2.distance(punto3);
        lado3 = punto3.distance(punto4);
        lado4 = punto4.distance(punto1);
        res = lado1 == lado2 && lado1 == lado3 && lado1 == lado4;
        res = res && punto1.mismaX(punto2) && punto3.mismaX(punto4);
        res = res && punto1.mismaY(punto4) && punto2.mismaY(punto3);
        return res;
    }
    
    boolean esRectangulo() {
        boolean res;
        double lado1, lado2, lado3, lado4;
        lado1 = punto1.distance(punto2);
        lado2 = punto2.distance(punto3);
        lado3 = punto3.distance(punto4);
        lado4 = punto4.distance(punto1);
        res = lado1 == lado3 && lado2 == lado4;
        res = res && punto1.mismaX(punto2) && punto3.mismaX(punto4);
        res = res && punto1.mismaY(punto4) && punto2.mismaY(punto3);
        return res;
    }
}