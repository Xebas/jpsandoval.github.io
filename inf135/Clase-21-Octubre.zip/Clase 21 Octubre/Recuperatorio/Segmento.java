class Segmento {
    Point inicial;
    Point fin;
    
    Segmento(Point ini, Point fin) {
        inicial = ini;
        this.fin = fin;
    }
    
    boolean consecutivo(Segmento otro) {
        return inicial.esIgual(otro.fin) || fin.esIgual(otro.inicial);
    }
    
    boolean esNulo() {
        return inicial.esIgual(fin);
    }
}