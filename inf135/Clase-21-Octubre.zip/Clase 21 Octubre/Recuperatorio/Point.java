class Point {
    int x;
    int y;
    
    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    double distance(Point otro) {
        double dx, dy;
        dx = x - otro.x;
        dy = y - otro.y;
        return Math.sqrt(dx*dx + dy*dy);
    }
    
    boolean esIgual(Point otro) {
        return x == otro.x && y == otro.y;
    }
    
    boolean mismaX(Point otro) {
        return x == otro.x;
    }
    
    boolean mismaY(Point otro) {
        return y == otro.y;
    }
}