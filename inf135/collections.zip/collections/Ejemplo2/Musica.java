public class Musica{
    String autor;
    String nombre;
    Musica(String a, String n){
        autor=a;
        nombre=n;
    }
    String asString(){
        return nombre +" - "+ autor;
    }
    String autor(){
        return autor;
    }
    String nombre(){
        return nombre;
    }
}
