import java.util.*;
public class OrganizadorMusica{
    ArrayList<Musica> musicas=new ArrayList<Musica>();
    
    OrganizadorMusica(){
        musicas=new ArrayList<Musica>();
    }
    
    void add(Musica m){
        musicas.add(m);
    }
    void listarMusicas(){
        for(int i=0;i<musicas.size();i++){
            Musica m=musicas.get(i);
            System.out.println(m.asString());
            
        }
    }
    ArrayList<Musica> musicaDeAutor(String autor){
        ArrayList<Musica> result=new ArrayList<Musica>();
        for(int i=0;i<musicas.size();i++){
            Musica m=musicas.get(i);
            if(m.autor().compareTo(autor)==0){
                //si el autor de esta musica es el que
                //estoy buscando
                result.add(m);
            }
        }
        return result;
    }
    boolean existeMusica(String nombre){
        boolean existe=false;
        int i=0;
        while(i<musicas.size() && !existe){
            Musica m=musicas.get(i);
            if(m.nombre().compareTo(nombre)==0){
                existe=true;
            }
            i++;
        }
        return existe;
    }
}
