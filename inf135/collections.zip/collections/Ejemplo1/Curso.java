import java.util.*;

public class Curso{
    private ArrayList<Estudiante> estudiantes;
    Curso(){
        estudiantes=new ArrayList<Estudiante>();
    }
    
    void agregarEstudiante(Estudiante e){
        estudiantes.add(e);
    }
    int numeroDeEstudiantes(){
        return estudiantes.size();
    }
    int mayorNota(){
        //asumimos que la mayor nota es 0
        int mayor=0;
        for(int i=0;i<estudiantes.size();i++){
            Estudiante e= estudiantes.get(i);
            if(e.nota()>mayor){
                // e tiene mayor nota
                mayor = e.nota();
            }
        }
        return mayor;
    }
    
    Estudiante estudianteMenorNota(){
        // asumimos que al menos hay un estudiante
        Estudiante menor=estudiantes.get(0);
        for(int i=1;i<estudiantes.size();i++){
            Estudiante e=estudiantes.get(i);
            if(e.nota()<menor.nota()){
                //e tiene menor nota que el menor
                menor=e;
            }
        }
        return menor;
    }
    double promedioDeNotas(){
        int suma=0;
        for(int i=0;i<estudiantes.size();i++){
            Estudiante e= estudiantes.get(i);
            suma = suma + e.nota();
            
        }
        return suma/estudiantes.size();
    }
}
