public class Estudiante{
    int nota;
    Estudiante(int n){
        nota = n;
    }
    int nota(){
        return nota;
    }
}