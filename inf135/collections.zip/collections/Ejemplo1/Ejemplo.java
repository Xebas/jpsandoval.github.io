class Ejemplo{
    public static void main(String[] args){
        Curso intro=new Curso();
        intro.agregarEstudiante(new Estudiante(20));
        intro.agregarEstudiante(new Estudiante(20));
        intro.agregarEstudiante(new Estudiante(20));
        intro.agregarEstudiante(new Estudiante(20));
        intro.agregarEstudiante(new Estudiante(20));
        intro.agregarEstudiante(new Estudiante(20));
        
        System.out.println("Mayor Nota: " +intro.mayorNota());
        System.out.println("Menor Nota: " +intro.estudianteMenorNota().nota());
        System.out.println("Promedio Notas: " +intro.promedioDeNotas());
    
    
    }
}