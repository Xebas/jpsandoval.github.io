public class Fraccion{
    int num;
    int den;
    Fraccion(int n,int d){
        num=n;
        den=d;
    }
    Fraccion sumar(Fraccion otra){
        int newNum=this.num+otra.num;
        int newDen=otra.den;
        Fraccion res=new Fraccion(newNum,newDen);
        return res;
    }
}