class Point{
    //int, double, String, Fraccion, Point
    int x;
    int y;
    Point(){
        x=0;
        y=0;
    }
    Point(int a, int b){
        x=a;
        y=b;
    }
    // 2,2 -- 1,1
    //int,double,String,Fraccion,Point
    double distance(Point otro){
        // ((x1-x2)^2+(y1-y2)^2)^1/2
        double dx = this.x - otro.x;
        double dy = this.y - otro.y;
        double suma = dx*dx + dy*dy;
        double res = Math.sqrt(suma);
        return res;
    }
}