public class Cuadrado extends Rectangulo
{
    Cuadrado(int lado) {
        super(lado, lado);
    }
    
    int ladoCuadrado() {
        return super.altura;
    }
}
