class Elefante extends Animal {
    double tamanioColmillo;
    
    Elefante(int a, int p, double tamCol) {
        super(a, p);
        tamanioColmillo = tamCol;
    }
    
    String emitirSonido() {
        return "prrr!!";
    }
    
    boolean colmilloEsMasGrande(Elefante otro) {
        boolean res;
        if(tamanioColmillo  > otro.tamanioColmillo){
            res = true;
        } else {
            res = false;
        }
        return res;
        //return tamanioColmillo  > otro.tamanioColmillo;
    }
}