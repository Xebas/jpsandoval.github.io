class Animal {
    int altura;
    int peso;
    
    Animal(int a, int p) {
        altura = a;
        peso = p;
    }
    
    String emitirSonido() {
        return "sonidoGenerico";
    }

    boolean esMasPesado(Animal otro) {
        return peso > otro.peso;
    }
    
    boolean esMasAlto(Animal otro) {
        return altura > otro.altura;
    }
}