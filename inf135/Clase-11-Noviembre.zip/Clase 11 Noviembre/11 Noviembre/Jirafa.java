class Jirafa extends Animal {
    Jirafa(int a, int p) {
        super(a, p);
    }
    
    String emitirSonido() {
        return "sonidoDeJirafa";
    }
}