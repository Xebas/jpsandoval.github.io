class Rectangulo{
    int base;
    int altura;
    
    Rectangulo(int b, int a) {
        base = b;
        altura = a;
    }
    
    double perimetro() {
        return 2*base + 2*altura;
    }
    
    double area() {
        return base * altura;
    }
}