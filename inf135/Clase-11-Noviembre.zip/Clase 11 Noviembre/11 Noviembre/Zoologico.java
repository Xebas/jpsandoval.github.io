import java.util.ArrayList;

class Zoologico {
    ArrayList<Animal> animales;
    
    Zoologico() {
        animales = new ArrayList<Animal>();
    }
    
    void agregarAnimal(Animal animal) {
        animales.add(animal);
    }
    
    String reporteMatutino() {
        String res = "";
        for(int i = 0; i < animales.size(); i++) {
            res = res + animales.get(i).emitirSonido() + " ";
        }
        int i = 0;
        while(i < animales.size()) {
            res = res + animales.get(i).emitirSonido() + " ";
            i++;
        }
        return res;
    }
}