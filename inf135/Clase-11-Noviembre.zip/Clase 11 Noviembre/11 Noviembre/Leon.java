class Leon extends Animal {
    Leon(int a, int p) {
        super(a, p);
    }
    
    String emitirSonido() {
        return "grrr!!";
    }
}