import java.util.Scanner;
/**
 * Invertir una cadena
 */
public class Ejemplo3{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        String linea = in.nextLine();
        int n=linea.length();
        String acum="";
        for(int i=(n-1);i>=0;i--){
            char c=linea.charAt(i);
            acum = acum +c;
        }
        System.out.println(acum);
    }
}
