import java.util.Scanner;

public class Ejemplo1{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int comb= factorial(n)/(factorial(m)*factorial(n-m));
        System.out.println(comb);
        
    }

    static int factorial(int n){
        int prod=1;
        for(int i=1;i<n;i++){
            prod = prod * i;
        }
        return prod;
    }
}