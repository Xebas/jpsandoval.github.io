import java.util.Scanner;

public class Ejemplo2{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        String linea=in.nextLine();
        int n=linea.length();
        int count=0;
        for(int i=0;i<n;i++){
            char c=linea.charAt(i);
            if(c=='a'){
                count = count+1;
            }
        }
        System.out.println(count);
    }
}