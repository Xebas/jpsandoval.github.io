import java.util.Scanner;
/**
 * leer numeros de consola hasta que el usuario ingrese el numero 0
 * mostrar el mayor de los numeros ingresados.
 */
class Ejemplo1{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int n=in.nextInt();
        int mayor=n;
        while(n!=0){
            n=in.nextInt();
            if(n>mayor){
                mayor=n;
            }
        }
        System.out.println(mayor);
    }
}