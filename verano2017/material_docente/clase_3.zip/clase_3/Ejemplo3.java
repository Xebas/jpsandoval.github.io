import java.util.*;
/**
 * Leer numeros de consola hasta que se ingrese 0
 * Mostrar el mayor de los numeros ingresados
 */
public class Ejemplo3{
   public static void main(String[] args){
       Scanner in=new Scanner(System.in);
       int n=in.nextInt();
       int mayor=n;
       while(n!=0){
           n=in.nextInt();
           if(n>mayor){
               mayor=n;
           }
       }
       System.out.println(mayor);
   }
}
