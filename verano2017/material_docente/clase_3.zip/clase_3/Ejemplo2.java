/**
 * imprimir la sumatoria del 1 al 100
 */
public class Ejemplo2{
   public static void main(String[] args){
       
       int sum=0;// acumulador
       for(int i=1;i<100;i++){
           sum = sum + i;
       }
   }
}
