import java.util.Scanner;
/**
 * Dado un mes (en formato numerico) imprimir el numero de dias de ese mes,
 * considerar que febrero siempre tien 28
 */
class Ejercicio2{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int mes=in.nextInt();
        int dias=31;
        if(mes<=7){
            if(mes ==2){dias=28;}
            else if(mes%2==0){dias=30;}
            else{dias=31;}
        }else{
            if(mes%2==0){dias=31;}
            else{dias=30;}
        }
        System.out.println(dias);
    }

}