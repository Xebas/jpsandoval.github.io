import java.util.Scanner;
/**
 * Dados dos numeros mostrar el mayor
 */
class Ejemplo1{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int numA=in.nextInt();
        int numB=in.nextInt();
        if(numA > numB){
            System.out.println(numA);
        }else{
            System.out.println(numB);        
        }
        
    }

}