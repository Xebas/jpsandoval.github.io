import java.util.Scanner;
/**
 * Dado un numero imprimir el valor absoluto del mismo, sin usar la funcion Math.abs(...);
 */

class Ejemplo2{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int num=in.nextInt();
        if(num<0){
            System.out.println(num*-1);
        }else{
            System.out.println(num);
        }        
    }
}