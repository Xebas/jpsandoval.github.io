import java.util.Scanner;

class Ejercicio1{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int numA = in.nextInt();
        int numB = in.nextInt();
        int numC = in.nextInt();
        int mayor = numA;
        if(numB>mayor){mayor=numB;}
        if(numC>mayor){mayor=numC;}
        System.out.println(mayor);
    }
}