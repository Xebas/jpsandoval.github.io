import java.util.Scanner;
/**
 * dado dos numeros x, y que representan un punto en un sistema de coordenadas cartesiano,
 * imprimir el cuadrante en el que se encuentran
 */
class Ejemplo3{
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        int y = in.nextInt();
        if(x>0 && y>0 ){
            System.out.println("I");
        }else{
            if(x<0 && y>0){
                System.out.println("II");
            }else{
                if(x<0 && y<0){
                    System.out.println("III");
                }else{
                    System.out.println("IV");
                }
            }
        }
        
        
    }

}