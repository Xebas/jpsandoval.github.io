class Rectangle{
    private Point origin;
    private Point corner;
    Rectangle(Point o,Point c){
        origin=o;
        corner=c;
    }
    Rectangle(Point o, int width,int height){
        origin=o;
        corner= new Point(o.getX()+width,o.getY()+height);
    }
    
    public double width(){
        return Math.abs(origin.getX()-corner.getX());
    }
    public double height(){
        return Math.abs(origin.getY()-corner.getY());
    }
    public double perimetro(){
        return width()*2+height()*2;
    }
    public double area(){
        return height()*width();
    }
    /**
     * 1. defina un método llamado topRigth, que devuelva el punto superior derecho del rectangulo.
     * public Point topRight(){ ... }
     */
    
    /**
     * 2. defina un método llamado bottomLeft, que devuelva el punto inferior izquierdo del rectangulo.
     * public Point bottomLeft(){ ... }
     */
    
    /**
     * 3. defina un método que permita determinar si un rectangulo es un cuadrado.
     * public boolean isSquare(){ ... }
     */
    
    /**
     * 4. defina un método que devuelva un punto que se encuentre en el centro del rectangulo.
     * public Point center(){...}
     */
    
}