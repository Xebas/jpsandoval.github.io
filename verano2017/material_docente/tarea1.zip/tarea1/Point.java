class Point{
    private int x;
    private int y;
    Point(int xo,int yo){
        this.x=xo;
        this.y=yo;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    public double distance(Point p){
        int dx=p.getX()-x;
        int dy=p.getY()-y;
        return Math.sqrt(dx*dx+dy*dy);
    }
}