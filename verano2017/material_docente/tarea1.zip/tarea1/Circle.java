class Circle{
    private Point center;
    private int ratio;
    
    Circle(Point c,int r){
        center=c;
        ratio=r;
    }
    public double area(){
        return Math.PI*ratio*ratio;
    }
    public boolean contains(Point other){
        return center.distance(other)<=ratio;
    }
    public Point getCenter(){
        return center;
    }
    public int getRatio(){
        return ratio;
    }
    public boolean intersect(Circle other){
        return center.distance(other.getCenter()) <= (ratio + other.getRatio());
    }
    /**
     * 5. Escriba un método que permita calcular el perimetro del circulo
     * public double perimetro(){...}
     */
    
    /**
     * 6. defina un método que verifique si un punto esta en el borde del circulo
     * public boolean estaEnBorde(Point p){...}
     */
    
    /**
     * 7. defina un método que devuelva un rectangulo, el rectangulo devuelto debe poder contener el circulo (circulo inscrito).
     * Ejemplo: http://www.todacultura.com/talleres/taller_dibujo/imagenes/circulo_inscrito2.gif
     * public Rectangle asRectangle(){...}
     */
}